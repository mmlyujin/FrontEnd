function validate() {
  if (document.getElementById("userid").value === "") {
    errorCheck(userid, "아이디를 입력해주세요");
    document.getElementById("userid").focus();
    return false;
  } else if (document.getElementById("userid").value.length < 8) {
    errorCheck(userid, "아이디는 8자리 이상이어야합니다");
    return false;
  } else {
    successCheck(userid);
  }

  if (document.getElementById("passwd").value === "") {
    errorCheck(passwd, "비밀번호를 입력해주세요");
    document.getElementById("passwd").focus();
    return false;
  } else if (document.getElementById("passwd").value.length < 12) {
    errorCheck(passwd, "비밀번호는 12자리 이상이어야합니다");
    return false;
  } else {
    successCheck(passwd);
  }

  https: location.href = "https://nid.naver.com/nidlogin.login";
}

// 오류글자 띄우기
function errorCheck(input, msg) {
  const formControl = input.parentElement;
  const small = formControl.querySelector("small");
  formControl.className = "form-control error";
  small.innerHTML = msg;
}

function successCheck(input) {
  const formControl = input.parentElement;
  formControl.className = "form-control success";
}

document.getElementById("frm").addEventListener("submit", (e) => {
  e.preventDefault();
});
