const str = document.querySelectorAll(".chk");
function selectAll() {
  //if (!document.querySelector("#chkAll").checked)
  if (document.querySelector("#chkAll").checked) {
    console.log(str.length);
    for (let i = 0; i < str.length; i++) {
      document.getElementsByClassName("chk")[i].checked = true;
    }
  } else {
    for (let i = 0; i < document.querySelectorAll(".chk").length; i++) {
      document.getElementsByClassName("chk")[i].checked = false;
    }
  }
}
function selectValidate() {
  if (document.getElementById("select").value === "") {
    alert("검색타입을 선택해주세요.");

    return false;
  }

  if (document.getElementById("search").value.trim() === "") {
    alert("검색어를 입력해 주세요");
    document.getElementById("search").focus();

    return false;
  }
  return true;
}

document.getElementById("frm").addEventListener("submit", (e) => {
  e.preventDefault;
  selectValidate();
});
