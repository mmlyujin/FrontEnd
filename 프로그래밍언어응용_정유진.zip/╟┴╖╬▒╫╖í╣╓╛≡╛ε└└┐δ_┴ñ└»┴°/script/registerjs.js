let select = document.getElementById("select");
let button = document.getElementById("button");
const checks = document.querySelectorAll("#check");
let chkNum = 0;

function validate() {
  if (document.getElementById("userid").value === "") {
    errorCheck(userid, "아이디를 입력해주세요");
    document.getElementById("userid").focus();
    return false;
  } else if (document.getElementById("userid").value.length < 8) {
    errorCheck(userid, "아이디는 8자리 이상이어야합니다");
    return false;
  } else {
    successCheck(userid);
  }
  //비번
  if (document.getElementById("passwd").value === "") {
    errorCheck(passwd, "비밀번호를 입력해주세요");
    document.getElementById("passwd").focus();
    return false;
  } else if (document.getElementById("passwd").value.length < 12) {
    errorCheck(passwd, "비밀번호는 12자리 이상이어야합니다");
    return false;
  } else {
    successCheck(passwd);
  }
  //비번체크
  if (document.getElementById("passwd2").value === "") {
    errorCheck(passwd2, "비밀번호를  재입력해주세요");
    document.getElementById("passwd2").focus();
    return false;
  } else if (
    document.getElementById("passwd").value !==
    document.getElementById("passwd2").value
  ) {
    errorCheck(passwd2, "비밀번호가 일치하지 않습니다");
    return false;
  } else {
    successCheck(passwd2);
  }
  //이메일
  if (document.getElementById("email").value === "") {
    errorCheck(email, "이메일을 입력해주세요");
    document.getElementById("email").focus();
    return false;
  } else if (!isEmailCheck(document.getElementById("email").value)) {
    errorCheck(email, "유효하지 않은 이메일입니다");
    return false;
  } else {
    successCheck(email);
  }

  //성별라디오버튼
  let isChecked = "";
  let gender = document.getElementById("gender");

  for (let i = 0; i < document.getElementsByName("gender").length; i++) {
    if (document.frm.gender[i].checked) {
      isChecked = document.frm.gender[i].value;
    }
  }

  if (isChecked == "") {
    errorCheck(gender, "성별을 선택하세요.");
    return false;
  } else {
    successCheck(gender);
  }

  console.log("radio");

  checks.forEach((check) => {});

  // 체크박스
  checks.forEach((chk) => {
    if (chk.checked) {
      chkNum++;
    }
  });
  if (chkNum == 0) {
    errorCheck(document.querySelector("#hobby"), "취미를 선택하세요.");
  } else {
    successCheck(document.querySelector("#hobby"));
  }

  console.log("체크박스");
  //지역 셀렉트
  if (select.value === "") {
    errorCheck(select, "지역을 선택하세요.");
    return false;
  } else {
    successCheck(select);
  }

  console.log("셀렉트");

  //자기소개
  if (document.getElementById("textarea").value === "") {
    errorCheck(
      document.getElementById("textarea").parentElement,
      "자기소개를 입력해주세요."
    );
    return false;
  } else {
    successCheck(document.getElementById("textarea").parentElement);
  }

  location.href = "/html/login.html";
}
//validate() 끝

function isEmailCheck(email) {
  let exp = /[a-zA-Z0-9+-\_.]+@[a-zA-Z]+\.[a-zA-z]+$/;
  return exp.test(email);
}
// 오류글자 띄우기
function errorCheck(input, msg) {
  const formControl = input.parentElement;
  const small = formControl.querySelector("small");
  formControl.className = "form-control error";
  small.innerHTML = msg;
}

function successCheck(input) {
  const formControl = input.parentElement;
  formControl.className = "form-control success";
}

document.getElementById("frm").addEventListener("submit", (e) => {
  e.preventDefault();
  validate();
});

function showPopup() {
  window.open("popUp.html", "a", "width=400, height=200, left=100, top=50");
}

//회원가입창 자기소개 스크립트
document.addEventListener("DOMContentLoaded", () => {
  const textarea = document.querySelector("textarea");
  const p = document.querySelector("p");

  textarea.addEventListener("keyup", () => {
    p.textContent = `입력한 글자수 : ${textarea.value.length}`;
  });
});
